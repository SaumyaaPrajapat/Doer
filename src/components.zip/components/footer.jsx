function footer() {
    return (
        <div>Footer</div>
    );
}

export default footer;
