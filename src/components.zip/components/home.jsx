import React from "react";
import "./home.css";
import logo from "./logo.png";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import MainPage from "./mainpage";
import SideNavbar from "./sidenavbar";

const App = () => {
  return (
    <div>
      <div className="navigation">
        <nav className="navbar navbar-expand-lg custom-navbar">
          <div className="container-fluid">
            <a className="navbar-brand" href="#">
              <img className="logo-image" src={logo} alt="Logo" />
              Doer
            </a>

            <form className="d-flex" role="search">
              <input
                className="form-control me-2"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
            </form>
          </div>
        </nav>
      </div>
      <div className="page-container">
        {/*sidenavbar starts*/}
        <div className="side-content">
          <SideNavbar />
        </div>
        {/*sidenavbar ends*/}
        {/*main page starts*/}
        <div className="main-content">
          <MainPage />
        </div>
        {/*main page ends*/}
      </div>
    </div>
  );
};

export default App;
